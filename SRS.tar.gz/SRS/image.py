import os
import io
from PIL import Image


# import glob, os
# from IPython.core.display import Image

def assure_path_exists(path):
    dir = os.path.dirname(path)
    dir = dir + "/sihimages"
    if not os.path.exists(dir):
        print
        "I am creating directory"
        os.makedirs(dir)


def uploaded_aadhar(username):
    if dicto[username][0] == 1:
        return 1
    else:
        return 0


def uploaded_pancard(username):
    if dicto[username][1] == 1:
        return 1
    else:
        return 0


def uploaded_otherdocs(username):
    if dicto[username][2] == 1:
        return 1
    else:
        return 0


# global dictionary having variables to check whether uploaded or not
dicto = {}


# [a,p,o,cnt]

def upload(username,doc,replac,image_path):
    import sqlite3
    import pandas as pd
    file = '/home/super--user/PycharmProjects/SRS/db.sqlite3'
    conn = sqlite3.connect(file)
    # conn.row_factory = sqlite3.Row  # This is the important part, here we are setting row_factory property of connection object to sqlite3.Row(sqlite3.Row is an implementation of row_factory)
    user = pd.read_sql_query("SELECT * FROM SRS_user", conn, index_col=None)

    my_image = Image.open(image_path)
    add_ad = "aadhaar"
    add_pn = "pancard"
    add_hsc = "hsc"
    add_ssc = "ssc"
    add_caste = "caste"

    abs_path = os.path.join(os.getcwd())
    abs_path = abs_path + "/sihimages"

    my_image = Image.open(image_path)
    filename, extension = os.path.splitext(image_path)
    # check directory created

    assure_path_exists(abs_path)
    if(doc==1):#aadhar
        my_image.save('/home/super--user/PycharmProjects/SRS/sihimages/{}_{}{}'.format(username, add_ad,extension))

        path = "/home/super--user/PycharmProjects/SRS/sihimages/" + username + "_" + add_ad + extension

        user.loc[user['user_name']==username,'aadhaar']=path

    if(doc==2):#pancard
        my_image.save('/home/super--user/PycharmProjects/SRS/sihimages/{}_{}{}'.format(username, add_pn, extension))

        path = "/home/super--user/PycharmProjects/SRS/sihimages/" + username + "_" + add_pn + extension

        user.loc[user['user_name']==username,'pancard']=path

    if(doc == 3):  #hsc
        my_image.save('/home/super--user/PycharmProjects/SRS/sihimages/{}_{}{}'.format(username, add_hsc, extension))

        path = "/home/super--user/PycharmProjects/SRS/sihimages/" + username + "_" + add_hsc + extension

        user.loc[user['user_name'] == username, 'hsc'] =path

    if(doc == 4):  #ssc
        my_image.save('/home/super--user/PycharmProjects/SRS/sihimages/{}_{}{}'.format(username, add_ssc, extension))

        path = "/home/super--user/PycharmProjects/SRS/sihimages/" + username + "_" + add_ssc + extension

        user.loc[user['user_name'] == username, 'ssc'] =path

    if(doc == 5):  #caste_certificate
        my_image.save('/home/super--user/PycharmProjects/SRS/sihimages/{}_{}{}'.format(username, add_caste, extension))

        path = "/home/super--user/PycharmProjects/SRS/sihimages/" + username + "_" + add_caste+ extension

        user.loc[user['user_name'] == username, 'caste_certificate'] =path



    '''dicto[username][3] = 3

    # open uploaded image
    while dicto[username][3]:
        # replace x.jpg by select_image function ()
        my_image = Image.open("x.jpg")
        filename, extension = os.path.splitext("x.jpg")
        if not uploaded_aadhar(username):
            # my_image.save(get_username+add_ad+extension)
            my_image.save('/home/saurabh/sihimages/{}_{}{}'.format(username, add_ad, extension))
            dicto[username][0] = 1
            dicto[username][3] -= 1
            path = "/home/saurabh/sihimages/" + username + "_" + add_ad + extension
            print
            path
            continue
        if not uploaded_pancard(username):
            my_image.save('/home/saurabh/sihimages/{}_{}{}'.format(username, add_pn, extension))
            dicto[username][3] -= 1
            dicto[username][1] = 1
            path = "/home/saurabh/sihimages/" + username + "_" + add_pn + extension
            print
            path
            continue
        if not uploaded_otherdocs(username):
            dicto[username][3] -= 1
            my_image.save('/home/saurabh/sihimages/{}_{}{}'.format(username, add_od, extension))
            dicto[username][2] = 1
            path = "/home/saurabh/sihimages/" + username + "_" + add_od + extension
            print
            path
            continue
        if dicto[username][0] == 0 and dicto[username][0] == 0 and dicto[username][0] == 0:
            print "Successful"
        else:
            upload(username)'''


def replace(username, doctype):
    add_ad = "aadhaar"
    add_pn = "pancard"
    add_od = "otherdocs"
    abs_path = os.path.join(os.getcwd())
    abs_path = abs_path + "/sihimages"
    filename, extension = os.path.splitext("x.jpg")
    dicto[username][3] = 1
    if doctype <= 2:
        dicto[username][doctype] = 0
    else:
        pass
    if doctype == 1:
        file_to_be_deleted = username + "_" + add_ad + ".jpg"
        os.remove(abs_path + "/" + file_to_be_deleted)
        my_image = Image.open("x.jpg")
        my_image.save('/home/saurabh/sihimages/{}_{}{}'.format(username, add_ad, extension))
        dicto[username][0] = 1
        dicto[username][3] -= 1
        path = "/home/saurabh/sihimages/" + username + "_" + add_ad + extension
        print
        path
    elif doctype == 2:
        my_image = Image.open("x.jpg")
        my_image.save('/home/saurabh/sihimages/{}_{}{}'.format(username, add_pn, extension))
        dicto[username][1] = 1
        dicto[username][3] -= 1
        path = "/home/saurabh/sihimages/" + username + "_" + add_pn + extension
        print
        path
    elif doctype == 3:
        my_image = Image.open("x.jpg")
        my_image.save('/home/saurabh/sihimages/{}_{}{}'.format(username, add_od, extension))
        dicto[username][2] = 1
        dicto[username][3] -= 1
        path = "/home/saurabh/sihimages/" + username + "_" + add_od + extension
        print
        path
    else:
        print
        "Wrong choice"
        dicto[username][3] = 0


def call(username, replac, doctype):
    # if username not in dicto.keys():
    # dicto[username] = [0, 0, 0, 0]
    upload(username)
