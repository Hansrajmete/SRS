from __future__ import unicode_literals
from django.db import models

class user(models.Model):
    user_name=models.CharField(primary_key=True,max_length=20)
    password=models.CharField(max_length=20)
    aadhaar=models.CharField(max_length=100)
    pancard=models.CharField(max_length=100)
    hsc=models.CharField(max_length=100)
    ssc=models.CharField(max_length=100)
    cast_certificate=models.CharField(max_length=100)




